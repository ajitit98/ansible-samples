# ansible

[![Image](https://github.com/yankils/ansible_for_beginners/blob/master/ansible_udemy_course.PNG "Ansible for the DevOps Beginners & System Admins ")](https://www.udemy.com/course/valaxy-ansible/?referralCode=9F36DC2010AEB6D64263)
